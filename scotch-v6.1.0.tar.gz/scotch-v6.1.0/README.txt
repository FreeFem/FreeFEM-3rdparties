The terms under which this copy of the Scotch 6.0 distribution
is provided to you are described in file "LICENSE_en.txt", located
in the same directory as this file.

If you accept them, please refer to file "INSTALL.txt", also
located in this directory, for the installation instructions.
