!
!  Include file for Fortran use of the Bag package in PETSc
!
#if !defined (PETSCBAGDEF_H)
#define PETSCBAGDEF_H

#define PetscBag PetscFortranAddr

#endif
